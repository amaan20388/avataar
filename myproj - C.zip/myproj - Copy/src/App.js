import React from 'react';

class HorizontalMenu extends React.Component {
  render() {
    return (
      <div>
        <div style={{ backgroundColor: 'black', padding: '20px', display: 'flex', alignItems: 'center' }}>
          <div style={{ marginRight: '40px' }}>
            {/* Add your logo here */}
            <img src="logo.png" alt="Logo" style={{ width: '50px', height: 'auto' }} />
          </div>
          <ul style={{ listStyleType: 'none', margin: 0, padding: 0, display: 'flex', alignItems: 'center' }}>
            <li style={{ marginRight: '40px' }}>
              <a href="#" style={{ color: 'white', textDecoration: 'none' }}>HOME</a>
            </li>
            <li style={{ marginRight: '40px' }}>
              <a href="#" style={{ color: 'white', textDecoration: 'none' }}>ELECTRONICS</a>
            </li>
            <li style={{ marginRight: '40px' }}>
              <a href="#" style={{ color: 'white', textDecoration: 'none' }}>BOOKS</a>
            </li>
            <li style={{ marginRight: '40px' }}>
              <a href="#" style={{ color: 'white', textDecoration: 'none' }}>MUSIC</a>
            </li>
            <li style={{ marginRight: '40px' }}>
              <a href="#" style={{ color: 'white', textDecoration: 'none' }}>MOVIES</a>
            </li>
            <li style={{ marginRight: '40px' }}>
              <a href="#" style={{ color: 'white', textDecoration: 'none' }}>CLOTHING</a>
            </li>
            <li style={{ marginRight: '40px' }}>
              <a href="#" style={{ color: 'white', textDecoration: 'none' }}>GAMES</a>
            </li>
            <li style={{ position: 'relative', marginRight: '40px' }}>
              <input type="text" placeholder="Search" style={{ border: 'none', borderBottom: '2px solid white', background: 'transparent', color: 'white', marginRight: '20px', paddingLeft: '25px' }} />
              <span style={{ position: 'absolute', top: '2px', left: '5px' }}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="white">
                  <path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 0 0 1.48-5.34c-.47-2.78-2.98-5-5.99-5.34a6.505 6.505 0 0 0-7.27 7.27c.34 3.01 2.56 5.52 5.34 5.99a6.5 6.5 0 0 0 5.34-1.48l.27.28v.79l4.25 4.25c.41.41 1.08.41 1.49 0 .41-.41.41-1.08 0-1.49L15.5 14zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                </svg>
              </span>
            </li>
          </ul>
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 'calc(100vh - 120px)' }}>
          <a href="https://example.com" style={{ display: 'flex', alignItems: 'center' }}>
            <img src="https://images.unsplash.com/photo-1710246650903-55b6f0e3a8fd?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Placeholder" style={{ maxWidth: '400px', maxHeight: '400px', width: 'auto', height: 'auto' }} />
          </a>
        </div>
      </div>
    );
  }
}

export default HorizontalMenu;
